# WireGuard: VPS Hub ↔ MikroTik Spokes

Hub-and-spoke VPN. The VPS is the always-on hub with a public IP; each
MikroTik is a spoke that dials out to it (works even if the MikroTik is
behind CGNAT / no public IP / no port forwarding).

Topology:
- Tunnel subnet: `10.10.0.0/24`
- VPS (hub): `10.10.0.1`
- Each MikroTik: auto-assigned `10.10.0.2`, `.3`, `.4`, ...
- Spokes route the whole `/24` through the tunnel, so any two MikroTiks can
  reach each other via the hub (the VPS must have `ip_forward=1`, which
  `vps-setup.sh` sets).

Files:
- `vps-setup.sh` – run once on the VPS. Installs WireGuard, creates the hub
  keypair and `wg0`, enables forwarding, opens the UDP port, starts the
  service.
- `wg-manager.sh` – run on the VPS whenever you connect a new MikroTik or
  need to edit/rotate/remove one. This is the generator.

## 1. Bootstrap the VPS (once)

```bash
scp vps-setup.sh wg-manager.sh root@your-vps:/root/
ssh root@your-vps
chmod +x vps-setup.sh wg-manager.sh
./vps-setup.sh
```

Note the printed **server public key** and **detected public IP** — you'll
need the IP (or a DNS name pointing at it) as the endpoint.

Edit the top of `wg-manager.sh` and set:

```bash
VPS_ENDPOINT="vpn.example.com"   # or the raw public IP printed above
```

(or pass it per-call: `VPS_ENDPOINT=1.2.3.4 ./wg-manager.sh add branch1`)

## 2. Connect a new MikroTik

On the VPS:

```bash
./wg-manager.sh add branch1
```

This:
1. Allocates the next free tunnel IP (e.g. `10.10.0.2`).
2. Generates a fresh WireGuard keypair **and** a pre-shared key for that
   router.
3. Appends a `[Peer]` block to `/etc/wireguard/wg0.conf` and hot-reloads
   `wg0` (`wg syncconf`) — no downtime for other already-connected sites.
4. Writes `/etc/wireguard/peers/branch1/mikrotik-branch1.rsc` — a ready-to
   -import RouterOS script containing that router's private key, the hub's
   public key, the psk, the endpoint, and its tunnel IP.

Get that file onto the router (any of these):

```bash
scp /etc/wireguard/peers/branch1/mikrotik-branch1.rsc admin@branch1-router:/
```

or drag it into **Files** in Winbox, or paste its contents straight into a
terminal session.

Then on the MikroTik:

```
/import file-name=mikrotik-branch1.rsc
```

Verify the tunnel:

```
/interface wireguard peers print
```

A non-zero `last-handshake` within the last couple of minutes means it's up.
On the VPS you can equally check with `wg show`.

## 3. Edit / rotate an existing MikroTik

Rotate a compromised or expiring key (keeps the same tunnel IP):

```bash
./wg-manager.sh edit branch1 --regen-keys
```

This regenerates the keypair + psk, replaces the `[Peer]` block on the hub,
hot-reloads `wg0`, and writes a **new** `mikrotik-branch1.rsc`. Re-import
that new file on the router the same way as step 2 — the old keys stop
working immediately once the hub is reloaded, so do this during a
maintenance window if the site is remote.

## 4. Remove a MikroTik

```bash
./wg-manager.sh remove branch1
```

Deletes its peer block from the hub, frees the registry entry, and archives
its key material under `peers/branch1.removed.<timestamp>/` (not deleted
outright, in case you need to audit it later).

## 5. Inventory

```bash
./wg-manager.sh list          # name / tunnel IP / pubkey / created date
./wg-manager.sh show branch1  # reprint a peer's .rsc if you lost the copy
```

## Notes / hardening

- Every peer gets its own pre-shared key (`PresharedKey`), so a single
  leaked private key isn't enough to establish a tunnel to the hub.
- Key material lives under `/etc/wireguard/peers/<name>/` with `700/600`
  permissions, root-only.
- The generated RouterOS firewall rule only *accepts* input on the
  `wg-vps` interface; it does not open anything on the router's WAN. Tighten
  further (e.g. restrict which hub IPs can reach which router services) to
  match your own firewall policy.
- `wg-manager.sh` uses `wg syncconf`, which reconciles the running interface
  with the conf file without tearing down unrelated peers' sessions — safe
  to run repeatedly while other sites are connected.
- If a MikroTik has no public IP/DDNS, that's fine: it always dials out to
  the VPS `endpoint-address`; the VPS never needs to reach the router's WAN.
