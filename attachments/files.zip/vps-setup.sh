#!/usr/bin/env bash
# vps-setup.sh
# One-time bootstrap of the WireGuard hub on the VPS.
# Run once, as root, on a fresh VPS. Idempotent (safe to re-run).
set -euo pipefail

### ---- CONFIG ----
WG_IFACE="wg0"
WG_DIR="/etc/wireguard"
WG_PORT="51820"
WG_SUBNET="10.10.0.1/24"     # hub's own tunnel address
### -----------------

if [[ $EUID -ne 0 ]]; then
  echo "Run as root (sudo $0)"; exit 1
fi

echo "==> Installing WireGuard tools"
if command -v apt-get >/dev/null 2>&1; then
  apt-get update -y
  apt-get install -y wireguard qrencode curl
elif command -v dnf >/dev/null 2>&1; then
  dnf install -y wireguard-tools qrencode curl
elif command -v yum >/dev/null 2>&1; then
  yum install -y epel-release
  yum install -y wireguard-tools qrencode curl
else
  echo "Unsupported distro -- install wireguard-tools manually and re-run."; exit 1
fi

umask 077
mkdir -p "$WG_DIR/peers"

echo "==> Generating hub keypair (if missing)"
if [[ ! -f "$WG_DIR/privatekey" ]]; then
  wg genkey | tee "$WG_DIR/privatekey" | wg pubkey > "$WG_DIR/publickey"
fi
SERVER_PRIV=$(cat "$WG_DIR/privatekey")

echo "==> Writing $WG_DIR/wg0.conf (if missing)"
if [[ ! -f "$WG_DIR/wg0.conf" ]]; then
cat > "$WG_DIR/wg0.conf" <<EOF
[Interface]
Address = $WG_SUBNET
ListenPort = $WG_PORT
PrivateKey = $SERVER_PRIV
SaveConfig = false

# --- peers are appended below by wg-manager.sh, one block per MikroTik ---
EOF
  chmod 600 "$WG_DIR/wg0.conf"
fi

echo "==> Enabling IPv4 forwarding"
cat > /etc/sysctl.d/99-wireguard.conf <<EOF
net.ipv4.ip_forward=1
EOF
sysctl --system >/dev/null

echo "==> Opening UDP $WG_PORT in the firewall (if ufw present)"
if command -v ufw >/dev/null 2>&1; then
  ufw allow "$WG_PORT"/udp || true
fi
# If you use nftables/iptables/a cloud security group instead,
# open UDP $WG_PORT to 0.0.0.0/0 there as well.

echo "==> Enabling and starting wg-quick@$WG_IFACE"
systemctl enable --now "wg-quick@$WG_IFACE"

echo
echo "================= HUB READY ================="
echo "Server public key : $(cat "$WG_DIR/publickey")"
echo "Listen port        : $WG_PORT/udp"
PUB_IP=$(curl -fsS ifconfig.me || echo "<could-not-detect-set-manually>")
echo "Detected public IP : $PUB_IP"
echo "==============================================="
echo "Set VPS_ENDPOINT=$PUB_IP (or your DNS name) at the top of wg-manager.sh"
echo "before running it for the first time."
