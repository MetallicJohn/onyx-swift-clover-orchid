#!/usr/bin/env bash
# wg-manager.sh
# Generator/editor for MikroTik WireGuard peers on the VPS hub.
# Run on the VPS, as root, after vps-setup.sh has been run once.
set -euo pipefail

### ---- CONFIG (edit these to match your setup) ----
WG_IFACE="wg0"
WG_DIR="/etc/wireguard"
WG_CONF="$WG_DIR/wg0.conf"
PEERS_DIR="$WG_DIR/peers"
REGISTRY="$WG_DIR/peers.tsv"          # name <TAB> ip <TAB> pubkey <TAB> created
WG_SUBNET_PREFIX="10.10.0"            # /24, hub = .1, peers auto-assigned from .2
WG_PORT="51820"
VPS_ENDPOINT="${VPS_ENDPOINT:-vpn.example.com}"   # override: VPS_ENDPOINT=1.2.3.4 ./wg-manager.sh add site1
SERVER_PUBKEY_FILE="$WG_DIR/publickey"
KEEPALIVE=25
MIKROTIK_WG_IFACE_NAME="wg-vps"       # interface name created on the MikroTik
### ---------------------------------------------------

require_root() { [[ $EUID -eq 0 ]] || { echo "Run as root."; exit 1; }; }
init_registry() { [[ -f "$REGISTRY" ]] || touch "$REGISTRY"; }
peer_exists() { grep -qP "^$1\t" "$REGISTRY" 2>/dev/null; }

next_ip() {
  local last
  last=$(cut -f2 "$REGISTRY" 2>/dev/null | sed "s/^$WG_SUBNET_PREFIX\.//" | sort -n | tail -1)
  [[ -z "$last" ]] && last=1
  echo "$WG_SUBNET_PREFIX.$((last + 1))"
}

# Hot-reload the interface from the conf file without dropping other peers'
# active sessions (no full restart of wg-quick).
sync_wg() {
  wg syncconf "$WG_IFACE" <(wg-quick strip "$WG_IFACE")
}

# Render the .rsc file a MikroTik admin imports to join the hub.
render_rsc() {
  local name=$1 ip=$2 priv=$3 psk=$4
  local server_pub; server_pub=$(cat "$SERVER_PUBKEY_FILE")
  local out="$PEERS_DIR/$name/mikrotik-$name.rsc"
  cat > "$out" <<EOF
# WireGuard join script for '$name'
# Generated $(date -Is) -- import on the MikroTik with:
#   /import file-name=mikrotik-$name.rsc
# then verify with:
#   /interface wireguard peers print

/interface wireguard
add name=$MIKROTIK_WG_IFACE_NAME listen-port=13231 private-key="$priv" comment="link to vps hub"

/interface wireguard peers
add interface=$MIKROTIK_WG_IFACE_NAME public-key="$server_pub" preshared-key="$psk" \\
    endpoint-address=$VPS_ENDPOINT endpoint-port=$WG_PORT \\
    allowed-address=$WG_SUBNET_PREFIX.0/24 persistent-keepalive=${KEEPALIVE}s \\
    comment="vps hub"

/ip address
add address=$ip/32 interface=$MIKROTIK_WG_IFACE_NAME network=$ip comment="$name tunnel address"

/ip route
add dst-address=$WG_SUBNET_PREFIX.0/24 gateway=$MIKROTIK_WG_IFACE_NAME comment="reach hub + other sites"

/ip firewall filter
add chain=input in-interface=$MIKROTIK_WG_IFACE_NAME action=accept place-before=0 comment="allow wg mgmt from hub"
EOF
  echo "$out"
}

write_peer_block() {
  local name=$1 pub=$2 psk=$3 ip=$4
  {
    echo ""
    echo "# BEGIN PEER $name"
    echo "[Peer]"
    echo "PublicKey = $pub"
    echo "PresharedKey = $psk"
    echo "AllowedIPs = $ip/32"
    echo "# END PEER $name"
  } >> "$WG_CONF"
}

remove_peer_block() {
  local name=$1
  sed -i "/# BEGIN PEER $name\$/,/# END PEER $name\$/d" "$WG_CONF"
}

add_peer() {
  local name=$1
  require_root; init_registry
  [[ -z "$name" ]] && { echo "usage: $0 add <name>"; exit 1; }
  peer_exists "$name" && { echo "Peer '$name' already exists -- use 'edit' or pick another name."; exit 1; }

  local ip; ip=$(next_ip)
  mkdir -p "$PEERS_DIR/$name"; chmod 700 "$PEERS_DIR/$name"

  wg genkey | tee "$PEERS_DIR/$name/privatekey" | wg pubkey > "$PEERS_DIR/$name/publickey"
  wg genpsk > "$PEERS_DIR/$name/psk"
  chmod 600 "$PEERS_DIR/$name"/*
  local priv pub psk
  priv=$(cat "$PEERS_DIR/$name/privatekey")
  pub=$(cat "$PEERS_DIR/$name/publickey")
  psk=$(cat "$PEERS_DIR/$name/psk")

  write_peer_block "$name" "$pub" "$psk" "$ip"
  printf "%s\t%s\t%s\t%s\n" "$name" "$ip" "$pub" "$(date -Is)" >> "$REGISTRY"
  sync_wg

  local rsc; rsc=$(render_rsc "$name" "$ip" "$priv" "$psk")
  echo "Added peer '$name' -> $ip"
  echo "RouterOS import script: $rsc"
}

edit_peer() {
  local name=$1; shift || true
  require_root
  [[ -z "$name" ]] && { echo "usage: $0 edit <name> [--regen-keys]"; exit 1; }
  peer_exists "$name" || { echo "No such peer: $name"; exit 1; }
  local ip; ip=$(grep -P "^$name\t" "$REGISTRY" | cut -f2)

  local regen=0
  for arg in "$@"; do [[ "$arg" == "--regen-keys" ]] && regen=1; done

  if [[ $regen -eq 1 ]]; then
    remove_peer_block "$name"
    wg genkey | tee "$PEERS_DIR/$name/privatekey" | wg pubkey > "$PEERS_DIR/$name/publickey"
    wg genpsk > "$PEERS_DIR/$name/psk"
    chmod 600 "$PEERS_DIR/$name"/*
    local priv pub psk
    priv=$(cat "$PEERS_DIR/$name/privatekey")
    pub=$(cat "$PEERS_DIR/$name/publickey")
    psk=$(cat "$PEERS_DIR/$name/psk")

    write_peer_block "$name" "$pub" "$psk" "$ip"
    sed -i "s/^$name\t[^\t]*\t.*/$name\t$ip\t$pub\t$(date -Is)/" "$REGISTRY"
    sync_wg

    local rsc; rsc=$(render_rsc "$name" "$ip" "$priv" "$psk")
    echo "Rotated keys for '$name' (IP unchanged: $ip)."
    echo "New RouterOS import script: $rsc"
    echo "IMPORTANT: re-import this .rsc on the MikroTik -- its old keys no longer work."
  else
    echo "Nothing to do. Supported edit flags: --regen-keys"
    exit 1
  fi
}

remove_peer() {
  local name=$1
  require_root
  [[ -z "$name" ]] && { echo "usage: $0 remove <name>"; exit 1; }
  peer_exists "$name" || { echo "No such peer: $name"; exit 1; }
  remove_peer_block "$name"
  sed -i "/^$name\t/d" "$REGISTRY"
  mv "$PEERS_DIR/$name" "$PEERS_DIR/${name}.removed.$(date +%s)" 2>/dev/null || true
  sync_wg
  echo "Removed peer '$name' from the hub."
}

list_peers() {
  init_registry
  printf "%-18s %-14s %-46s %s\n" "NAME" "IP" "PUBKEY" "CREATED"
  while IFS=$'\t' read -r name ip pub created; do
    printf "%-18s %-14s %-46s %s\n" "$name" "$ip" "$pub" "$created"
  done < "$REGISTRY"
}

show_peer() {
  local name=$1
  local f="$PEERS_DIR/$name/mikrotik-$name.rsc"
  [[ -f "$f" ]] || { echo "No .rsc on file for '$name' -- did you run 'add' or 'edit --regen-keys'?"; exit 1; }
  cat "$f"
}

usage() {
  cat <<EOF
wg-manager.sh -- generate/edit MikroTik WireGuard peers on the VPS hub

Usage:
  $0 add <name>                  Create a new MikroTik peer (auto IP + keys + psk),
                                  print path to its RouterOS import script.
  $0 edit <name> --regen-keys    Rotate a peer's keys (invalidates the old .rsc;
                                  re-import the new one on that router).
  $0 remove <name>                Remove a peer from the hub and disable its tunnel.
  $0 list                         List all registered peers.
  $0 show <name>                  Print a peer's RouterOS import script again.

Environment:
  VPS_ENDPOINT=1.2.3.4 $0 add branch1   Override the endpoint baked into new .rsc files.
EOF
}

cmd="${1:-}"; shift || true
case "$cmd" in
  add)    add_peer "${1:-}" ;;
  edit)   edit_peer "${1:-}" "${2:-}" ;;
  remove) remove_peer "${1:-}" ;;
  list)   list_peers ;;
  show)   show_peer "${1:-}" ;;
  *) usage; exit 1 ;;
esac
